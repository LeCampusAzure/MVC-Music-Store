﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMusicStore.Helpers
{
    public class ShoppingCartHelper
    {
        const string CartSessionKey = "CartId";
        HttpContext context;

        public ShoppingCartHelper(HttpContext _context)
        {
            context = _context;
        }

        public string GetCartId()
        {
            context.Session.LoadAsync().Wait();
            if (context.Session.GetString(CartSessionKey) == null)
            {
                if (!string.IsNullOrWhiteSpace(context.User.Identity.Name))
                {
                    context.Session.SetString(CartSessionKey, context.User.Identity.Name);
                }
                else
                {
                    // Generate a new random GUID using System.Guid class
                    Guid tempCartId = Guid.NewGuid();

                    // Send tempCartId back to client as a cookie
                    context.Session.SetString(CartSessionKey, tempCartId.ToString());
                    context.Session.CommitAsync().Wait();
                }
            }

            return context.Session.GetString(CartSessionKey);
        }
    }
}
